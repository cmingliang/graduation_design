package com.warmnut.controller;

import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

public class LoginController {
	
	

}
