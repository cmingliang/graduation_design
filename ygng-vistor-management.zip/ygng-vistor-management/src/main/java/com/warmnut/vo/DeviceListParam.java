package com.warmnut.vo;

import com.warmnut.common.bean.PageParam;

public class DeviceListParam extends PageParam{
	
	

}
