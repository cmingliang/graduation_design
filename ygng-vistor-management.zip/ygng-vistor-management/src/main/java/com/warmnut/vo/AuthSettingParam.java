package com.warmnut.vo;

public class AuthSettingParam {	
	private Integer status;
	private Integer[] devices;
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer[] getDevices() {
		return devices;
	}
	public void setDevices(Integer[] devices) {
		this.devices = devices;
	}
	
	

}
