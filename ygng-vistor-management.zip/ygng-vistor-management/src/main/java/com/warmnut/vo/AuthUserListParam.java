package com.warmnut.vo;

import com.warmnut.common.bean.PageParam;

public class AuthUserListParam extends PageParam{
	private Integer deviceId;

	public Integer getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}
	
	

}
