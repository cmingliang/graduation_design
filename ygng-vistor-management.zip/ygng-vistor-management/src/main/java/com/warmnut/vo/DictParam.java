package com.warmnut.vo;

import com.warmnut.common.bean.PageParam;

public class DictParam  extends PageParam{

}
