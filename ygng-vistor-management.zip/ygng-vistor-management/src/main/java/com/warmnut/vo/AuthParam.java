package com.warmnut.vo;

public class AuthParam {
	private Integer[] devices;
	private Integer[] userIds;
	public Integer[] getDevices() {
		return devices;
	}
	public void setDevices(Integer[] devices) {
		this.devices = devices;
	}
	public Integer[] getUserIds() {
		return userIds;
	}
	public void setUserIds(Integer[] userIds) {
		this.userIds = userIds;
	}
	
	

}
