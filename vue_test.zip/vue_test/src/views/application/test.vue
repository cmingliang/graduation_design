<template>
  <ul>
    <li><h4>多媒体</h4>
      <dl>
        <dd class="false">摄影美化</dd>
        <dd class="false">视频摄像</dd>
        <dd class="false">相册图库</dd>
        <dd class="false">直播</dd>
        <dd class="false">音乐</dd>
        <dd class="false">游戏</dd>
        <dd class="false">新闻阅读</dd>
        <dd class="false">娱乐</dd>
      </dl>
    </li>
    <li><h4>生活</h4>
      <dl>
        <dd class="false">运动健身</dd>
        <dd class="false">医疗健康</dd>
        <dd class="false">交通出行</dd>
        <dd class="false">旅游</dd>
        <dd class="false">美食餐饮</dd>
        <dd class="false">同城商务</dd>
        <dd class="false">电商购物</dd>
        <dd class="false">美容美妆</dd>
      </dl>
    </li>
    <li><h4>其他</h4>
      <dl>
        <dd class="false">教育学习</dd>
        <dd class="false">金融理财</dd>
        <dd class="false">办公商务</dd>
        <dd class="false">安全</dd>
        <dd class="false">工具</dd>
        <dd class="false">通讯社交</dd>
        <dd class="false">母婴儿童</dd>
        <dd class="false">其他</dd>
      </dl>
    </li>
  </ul>

  <ul>
    <li><h4>个人/家庭</h4>
      <dl>
        <dd class="false">智能家居</dd>
        <dd class="false">智能穿戴</dd>
        <dd class="false">游戏设备</dd>
        <dd class="false">家庭机器人</dd>
        <dd class="false">智能玩具</dd>
        <dd class="false">VR/AR</dd>
        <dd class="false">智能车载</dd>
        <dd class="false">其他</dd>
      </dl>
    </li>
    <li><h4>企业/机构</h4>
      <dl>
        <dd class="false">安防监控</dd>
        <dd class="false">门禁监控</dd>
        <dd class="false">智能交通</dd>
        <dd class="false">智能办公</dd>
        <dd class="false">机器人</dd>
        <dd class="false">智能医疗</dd>
        <dd class="false">广告营销</dd>
        <dd class="false">其他</dd>
      </dl>
    </li>
  </ul>
</template>

<script>
  export default {
    name: "test"
  }
</script>

<style scoped>

</style>
