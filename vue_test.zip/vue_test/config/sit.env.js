module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"sit"',
  // BASE_API: '"http://192.168.100.132:8080/"'
  BASE_API: '"/"'
}

